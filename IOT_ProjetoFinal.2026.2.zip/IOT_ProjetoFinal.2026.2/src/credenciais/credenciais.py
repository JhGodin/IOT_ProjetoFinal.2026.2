# Configuração local do Python. Consulte credenciais.exemplo.py
# Este arquivo esta no .gitgnore e nao dece ser enviado ao GitHbu

BD_TIPO = "postgresql"  
BD_HOST = "postgresql.janks.dev.br"  # Endereco do computador que hospeda o banco.
BD_PORTA = 5432  
BD_NOME = "projeto"  
BD_USUARIO = "iot"  
BD_SENHA = "pepcon-garton"  

# MQTT: ID exclusivo para o Python, diferente do ID usado pelo ESP.
MQTT_CLIENTE_ID = "ID_UNICO_DO_TOTEM"
MQTT_USUARIO = "aula"
MQTT_SENHA = "zowmad-tavQez"
