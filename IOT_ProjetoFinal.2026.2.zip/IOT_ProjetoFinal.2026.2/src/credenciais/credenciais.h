#pragma once

// Configuração local do ESP32. Preencha SOMENTE na sua maquina
// Este arquivo esta no .gitgnore e nao dece ser enviado ao GitHbu

const char WIFI_NOME[] = "LabIoT";
const char WIFI_SENHA[] = "4n1m4l5@))!!";
const char MQTT_CLIENTE_ID[] = "totem1w242314";
const char MQTT_USUARIO[] = "aula";
const char MQTT_SENHA[] = "zowmad-tavQez";
